import os
import sys
from PIL import Image
import requests


class FindObject:
    def __init__(self, country_name):
        self.cord_x = 37.622504
        self.cord_y = 55.75
        self.z = 1
        self.type = 'sat'
        self.country_name = country_name
        self.input()

    def getImage(self):
        map_request = f"http://static-maps.yandex.ru/1.x/?l={self.type}&ll={self.cord_x},{self.cord_y}&z={self.z}&pt={self.flag_x},{self.flag_y},comma"
        response = requests.get(map_request)

        if not response:
            print("Ошибка выполнения запроса:")
            print(map_request)
            print("Http статус:", response.status_code, "(", response.reason, ")")
            sys.exit(1)

        # Запишем полученное изображение в файл.
        self.map_file = "map.jpg"
        with open(self.map_file, "wb") as file:
            file.write(response.content)


    def input(self):
        self.flag = True
        self.z = 3

        geocoder_api_server = "http://geocode-maps.yandex.ru/1.x/"

        geocoder_params = {
            "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
            "geocode": self.country_name,
            "format": "json"}

        response = requests.get(geocoder_api_server, params=geocoder_params)

        if not response:
            print("Ошибка выполнения запроса:")
            print("Http статус:", response.status_code, "(", response.reason, ")")
            sys.exit(1)

        # Преобразуем ответ в json-объект
        json = response.json()
        # Получаем первый топоним из ответа геокодера.
        toponym = json["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
        # Координаты центра топонима:
        toponym_coodrinates = toponym["Point"]["pos"]
        # Долгота и широта:
        toponym_longitude, toponym_lattitude = toponym_coodrinates.split(" ")

        self.cord_x = float(toponym_longitude)
        self.cord_y = float(toponym_lattitude)
        self.flag_x = self.cord_x
        self.flag_y = self.cord_y

        self.getImage()


