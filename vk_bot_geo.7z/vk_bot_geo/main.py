from choice import *
from vk_bot import *

country_name, country_description = Choice()
bot(country_name, country_description)