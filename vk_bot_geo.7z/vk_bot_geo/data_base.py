from flask import Flask
from data import db_session
from data import users

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def add(id):
    db_session.global_init("db/blogs.sqlite")
    user = users.User()
    user.id = str(id)
    user.points = 0
    session = db_session.create_session()
    session.add(user)
    session.commit()
    # app.run()


def change(id, points):
    db_session.global_init("db/blogs.sqlite")
    session = db_session.create_session()
    editedUser = session.query(users.User).filter_by(id=id).one()
    editedUser.points = points
    session.add(editedUser)
    session.commit()


def get(id):
    db_session.global_init("db/blogs.sqlite")
    session = db_session.create_session()
    editedUser = session.query(users.User).filter_by(id=id).one()
    return editedUser.points


