import sqlite3
import random
from image_of_country import *


def Choice():

    country_id = random.randint(1, 22)

    con = sqlite3.connect("countries.db")
    cur = con.cursor()

    country_name = cur.execute(f"""SELECT Country_name FROM Names
                WHERE id = {country_id}""").fetchone()[0]

    country_description = cur.execute(f"""SELECT description FROM Description
                WHERE id = {country_id}""").fetchone()[0]
    con.close()
    FindObject(country_name)
    return [country_name, country_description]

