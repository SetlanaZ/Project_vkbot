import datetime
import sqlalchemy
from .db_session import SqlAlchemyBase


class User(SqlAlchemyBase):
    __tablename__ = 'users'

    id = sqlalchemy.Column(sqlalchemy.String,
                           primary_key=True)
    points = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)

