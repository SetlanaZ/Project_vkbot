import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
import random
from choice import *
from data_base import *
from commands import *


def bot(country_name, country_description):
    vk_session = vk_api.VkApi(
        token='')

    longpoll = VkBotLongPoll(vk_session, "194917927")
    country_name, country_description = country_name, country_description
    is_first = True
    is_continue = False
    not_answered = False
    no_mistake = True
    map_show = True
    map_show_always = False
    points = 0

    for event in longpoll.listen():

        if event.type == VkBotEventType.MESSAGE_NEW:
            vk = vk_session.get_api()

            response = vk.users.get(user_id=event.obj.message['from_id'])

            user_id = response[0]['id']
            message_receive = event.obj.message['text']

            if message_receive == "/map":
                map_show_always = map(message_receive, map_show_always)
                map_show = map_show_always
                if map_show:
                    vk.messages.send(peer_id=event.object.peer_id, user_id=event.obj.message['from_id'],
                                     message='Карта включена',
                                     random_id=random.randint(0, 2 ** 64))
                else:
                    vk.messages.send(peer_id=event.object.peer_id, user_id=event.obj.message['from_id'],
                                     message='Карта выключена',
                                     random_id=random.randint(0, 2 ** 64))

            if message_receive == "/points":
                vk.messages.send(user_id=event.obj.message['from_id'],
                                 message=f"{str(get(user_id))}",
                                 random_id=random.randint(0, 2 ** 64))

            if is_first:
                vk.messages.send(user_id=event.obj.message['from_id'],
                                 message="Привет! Это гео-бот.\nЯ присылаю тебе описание какой-либо страны, а "
                                         "твоя задача - угадать эту страну.\nЧтобы играть было немного легче - сначала "
                                         "я буду прикреплять вместе с описанием еще и карту с отменткой в центре этой "
                                         "страны.\nЗа каждый правильный ответ тебе будут начисляться баллы:\n"
                                         "1.За ответ с первой попытки +2 балла.\n"
                                         "2.За ответ со второй попытки +1 балл.\n"
                                         "Далее баллы не начисляются и тебе показывается правильный ответ.\n"
                                         "После того, как ты наберешь 20 баллов, карта больше не будет показываться.\n"
                                         "Но ты всегда можешь прописать команду /map чтобы включить постоянное отображение карты.\n"
                                         "Напиши /points для того, чтобы узнать свои баллы.\n"
                                         "Начать?",
                                 random_id=random.randint(0, 2 ** 64))
                add(user_id)
                is_first = False

            elif is_continue:
                message_receive = event.obj.message['text']
                if 'привет' in message_receive.lower():
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Привет! Рад снова тебя видеть! Продолжить игру?',
                                     random_id=random.randint(0, 2 ** 64))

                    is_continue = False

            elif not is_first and not is_continue and not not_answered:
                message_receive = event.obj.message['text']
                if int(get(user_id)) >= 20 and not map_show_always:
                    map_show = False

                if 'да' in message_receive.lower():

                    try:
                        message_text = f"{country_description}\n"
                        upload = vk_api.VkUpload(vk)
                        photo = upload.photo_messages('map.jpg')
                        owner_id = photo[0]['owner_id']
                        photo_id = photo[0]['id']
                        access_key = photo[0]['access_key']
                        attachment = f'photo{owner_id}_{photo_id}_{access_key}'
                        not_answered = True
                    except:
                        message_text = "Извините, произошла ошибка."

                    if map_show:
                        vk.messages.send(peer_id=event.object.peer_id, user_id=event.obj.message['from_id'],
                                         message=message_text,
                                         attachment=attachment,
                                         random_id=random.randint(0, 2 ** 64))
                    else:
                        vk.messages.send(peer_id=event.object.peer_id, user_id=event.obj.message['from_id'],
                                         message=message_text,
                                         random_id=random.randint(0, 2 ** 64))

                elif 'нет' in message_receive.lower():
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Что ж, пока. Пиши еще.\nЕсли захочешь продолжить - '
                                             'просто напиши "Привет"',
                                     random_id=random.randint(0, 2 ** 64))
                    is_continue = True
            elif not_answered:
                message_receive = event.obj.message['text']
                if message_receive == "/map":
                    # map_show_always = map(message_receive, map_show_always)
                    # map_show = map_show_always
                    message_text = f"{country_description}\n"
                    if map_show:
                        vk.messages.send(peer_id=event.object.peer_id, user_id=event.obj.message['from_id'],
                                         message=message_text,
                                         attachment=attachment,
                                         random_id=random.randint(0, 2 ** 64))
                    else:
                        vk.messages.send(peer_id=event.object.peer_id, user_id=event.obj.message['from_id'],
                                         message=message_text,
                                         random_id=random.randint(0, 2 ** 64))
                elif message_receive == "/points":
                    pass

                elif message_receive.lower() == country_name.lower() and no_mistake:
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Верно! Ты получаешь +2 балла.\nПродолжить?',
                                     random_id=random.randint(0, 2 ** 64))

                    points = int(get(user_id)) + 2
                    change(user_id, points)

                    country_name, country_description = Choice()
                    not_answered = False

                elif message_receive.lower() == country_name.lower() and not no_mistake:
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Верно! Ты ответил со второй попытки, поэтому получаешь +1 балл.'
                                             '\nПродолжить?',
                                     random_id=random.randint(0, 2 ** 64))

                    points = int(get(user_id)) + 1
                    change(user_id, points)

                    country_name, country_description = Choice()

                    not_answered = False
                    no_mistake = True
                elif message_receive.lower() != country_name.lower() and no_mistake:
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Это неправильный ответ.Не расстраивайся!'
                                             '\nПопробуй еще раз.',
                                     random_id=random.randint(0, 2 ** 64))

                    no_mistake = False
                elif message_receive.lower() != country_name.lower() and not no_mistake:
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Это тоже неправильный ответ. Ты ошибся два раза подряд, '
                                             f'поэтому не получаешь балл.\nПравильный ответ:{country_name}'
                                             '\nПродолжить?',
                                     random_id=random.randint(0, 2 ** 64))



                    country_name, country_description = Choice()

                    not_answered = False
                    no_mistake = True
