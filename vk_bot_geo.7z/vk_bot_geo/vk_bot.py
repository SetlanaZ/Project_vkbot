import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
import random
from choice import *


def bot(country_name, country_description):
    vk_session = vk_api.VkApi(
        token='b71476ef01e3fa3809bf35b24e36dd38cc6a6969cacef037d87b194bb486dffdd6bd053d7f585cfcbd690')

    longpoll = VkBotLongPoll(vk_session, "194917927")
    country_name, country_description = country_name, country_description
    is_first = True
    is_continue = False
    not_answered = False
    no_mistake = True

    for event in longpoll.listen():

        if event.type == VkBotEventType.MESSAGE_NEW:
            vk = vk_session.get_api()

            if is_first:
                vk.messages.send(user_id=event.obj.message['from_id'],
                                 message="Привет! Правила Начать?",
                                 random_id=random.randint(0, 2 ** 64))
                is_first = False

            elif is_continue:
                message_receive = event.obj.message['text']
                if 'привет' in message_receive.lower():
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Привет! Рад снова тебя видеть! Продолжить игру?',
                                     random_id=random.randint(0, 2 ** 64))
                    is_continue = False

            elif not is_first and not is_continue and not not_answered:
                message_receive = event.obj.message['text']

                #

                if 'да' in message_receive.lower():
                    try:
                        message_text = f"{country_description}\n"
                        upload = vk_api.VkUpload(vk)
                        photo = upload.photo_messages('map.jpg')
                        owner_id = photo[0]['owner_id']
                        photo_id = photo[0]['id']
                        access_key = photo[0]['access_key']
                        attachment = f'photo{owner_id}_{photo_id}_{access_key}'
                        not_answered = True
                    except:
                        message_text = "Извините, произошла ошибка."

                    vk.messages.send(peer_id=event.object.peer_id, user_id=event.obj.message['from_id'],
                                     message=message_text,
                                     attachment=attachment,
                                     random_id=random.randint(0, 2 ** 64))

                elif 'нет' in message_receive.lower():
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Что ж, пока. Пиши еще.\nЕсли захочешь продолжить - '
                                             'просто напиши "Привет"',
                                     random_id=random.randint(0, 2 ** 64))
                    is_continue = True
            elif not_answered:
                message_receive = event.obj.message['text']
                if message_receive.lower() == country_name.lower() and no_mistake:
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Верно! Ты получаешь +2 балла.\nПродолжить?',
                                     random_id=random.randint(0, 2 ** 64))

                    # ОБРАЩЕНИЕ
                    # К
                    # БД

                    country_name, country_description = Choice()

                    not_answered = False
                elif message_receive.lower() == country_name.lower() and not no_mistake:
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Верно! Ты ответил со второй попытки, поэтому получаешь +1 балл.'
                                             '\nПродолжить?',
                                     random_id=random.randint(0, 2 ** 64))

                    country_name, country_description = Choice()
                    not_answered = False
                    no_mistake = True
                elif message_receive.lower() != country_name.lower() and no_mistake:
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Это неправильный ответ.Не расстраивайся!'
                                             '\nПопробуй еще раз.',
                                     random_id=random.randint(0, 2 ** 64))

                    no_mistake = False
                elif message_receive.lower() != country_name.lower() and not no_mistake:
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message='Это тоже неправильный ответ. Ты ошибся два раза подряд, '
                                             f'поэтому не получаешь балл.\nПравильный ответ:{country_name}'
                                             '\nПродолжить?',
                                     random_id=random.randint(0, 2 ** 64))

                    # ОБРАЩЕНИЕ К БД

                    country_name, country_description = Choice()

                    not_answered = False
                    no_mistake = True




