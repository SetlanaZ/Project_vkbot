def map(message, map_alw):
    if message == "/map" and map_alw is False:
        return True

    elif message == "/map" and map_alw is True:
        return False

